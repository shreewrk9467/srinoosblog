import { redirect } from 'next/navigation';

export default function DealsPage() {
  redirect('/offers');
}
